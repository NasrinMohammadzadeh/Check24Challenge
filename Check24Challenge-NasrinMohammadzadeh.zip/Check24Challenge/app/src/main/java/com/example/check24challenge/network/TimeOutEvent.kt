package com.example.check24challenge.network

class TimeOutEvent
