package com.example.check24challenge.model

data class PriceModel(
    val value: Double,
    val currency: String
)
