package com.example.check24challenge.model

data class FilterItemModel(
    val title: String,
    var isSelected:Boolean
)
