package com.example.check24challenge.model

data class HeaderModel(
    val headerTitle: String,
    val headerDescription: String
)
