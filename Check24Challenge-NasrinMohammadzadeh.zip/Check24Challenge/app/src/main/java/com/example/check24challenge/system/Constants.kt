package com.example.check24challenge.system

object Constants {
    const val PRODUCT_URL = "https://app.check24.de/products-test.json"
}